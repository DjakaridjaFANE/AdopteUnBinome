<?php
session_start();
require('db-config.php');
require('db-connexion.php');
require('Deconnexion-admin.php');
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Demandes de binômes</title>
    </head>
    <body>
        <table>
                <?php
                    if ($_SESSION['ConnectAdmin'] == true){
                        $req = $cnx->prepare("SELECT * FROM matieres");

                        $req->execute();
                        $ligne=$req->fetch(PDO::FETCH_OBJ);
                        while ($ligne){
                            echo "<tr><td><h3>".$ligne->libelle." : </h3></td></tr>";
                            $req_pre = $cnx->prepare("SELECT * FROM demande WHERE libelleMatiere = :matiere");
                            $req_pre->bindValue(':matiere', $ligne->libelle, PDO::PARAM_STR);
                            $req_pre->execute();
                            $ligne2=$req_pre->fetch(PDO::FETCH_OBJ);
                            if($ligne2){
                                while($ligne2){
                                        echo "<tr><td>Demandeur : ".$ligne2->demandeur." Destinataire : ".$ligne2->destinataire." Statut : ".$ligne2->statut."</td></tr>";
                                        
                                    $ligne2=$req_pre->fetch(PDO::FETCH_OBJ);
                                }
                            }else{ echo " <tr><td>Aucune demande dans cette matière</td></tr>";}
                            $ligne=$req->fetch(PDO::FETCH_OBJ);
                        }?>
        </table>
        <br>
        <a href='accueil-admin.php'>Accueil</a><br>
        <?php echo constant('DECO');
        ?>
    </body>
</html>
        <?php 
            }else{
            header("Location: Connexion.php");}
        ?>
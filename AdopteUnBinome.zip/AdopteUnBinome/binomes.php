<?php
session_start();
require('db-config.php');
require('db-connexion.php');
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Mes binômes</title>
        <link rel="stylesheet" href="css/w3.css">
        <link rel="stylesheet" href="css/lato.css">
        <link rel="stylesheet" href="css/all.min.css">
    </head>
          <!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a  href="Accueil.php"  class="w3-bar-item w3-button w3-padding-large"><i class="fa fa-home"></i></a>
    <a href="profil.php" class="w3-bar-item w3-button w3-padding-large">Profil</a>
    <a href="chercher.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Chercher un binôme</a>
    <a href="demandes.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Demandes de binômes</a>
    <a href="binomes.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Mes binômes</a>
    <a href="palmares.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Palmarès</a>
    <a href="accueil.php?afaire=deconnexion" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Déconnexion</a>
    <div class="w3-dropdown-hover w3-hide-small">
      <button class="w3-padding-large w3-button" title="More">MORE <i class="fa fa-caret-down"></i></button>     
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a href="#" class="w3-bar-item w3-button">Merchandise</a>
        <a href="#" class="w3-bar-item w3-button">Extras</a>
        <a href="#" class="w3-bar-item w3-button">Media</a>
      </div>
    </div>
    <a href="javascript:void(0)" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fa fa-search"></i></a>
  </div>
</div>

<div class="w3-content" style="max-width:2000px;margin-top:50px">
    <body>


        <?php
            if ($_SESSION['Connect'] == true)
            {
            $req_pre = $cnx->prepare("SELECT * FROM binomes WHERE binome1 = :login OR binome2 = :login");
            $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
            $req_pre->execute();
            $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
            if(!$ligne){echo "Aucun binôme ";}else{
                while ($ligne){
                    if( $ligne->binome1 == $_SESSION['login'])
                    {
                        echo "<br><h3>".$ligne->libelleMatiere." : </h3>";

                        $req = $cnx->prepare("SELECT * FROM etudiants WHERE login = :login");

                        $req->bindValue(':login', $ligne->binome2, PDO::PARAM_STR);

                        $req->execute();
                        $ligne_req=$req->fetch(PDO::FETCH_OBJ);
                    
                        while ($ligne_req){
                            $compT = explode(',',$ligne_req->competencesTech);
                            $compS = explode(',',$ligne_req->competencesSoft);

                            echo "<h4>".$ligne_req->prenom." ".$ligne_req->nom." : </h4><br> Compétences techniques : <br>";
                                if(!empty($compT[0])){
                                    foreach ($compT as $key => $value){
                                        
                                        $req_pre2 = $cnx->prepare("SELECT * FROM competences WHERE idCompetence = :id");

                                        $req_pre2->bindValue(':id', $value, PDO::PARAM_STR);
                                
                                        $req_pre2->execute();
                                        $ligne_pre2=$req_pre2->fetch(PDO::FETCH_OBJ);


                                        $req_pre3 = $cnx->prepare("SELECT * FROM notes WHERE idCompetence = :id AND login = :login");

                                        $req_pre3->bindValue(':id', $value, PDO::PARAM_STR);
                                        $req_pre3->bindValue(':login', $ligne->binome2, PDO::PARAM_STR);

                                        $req_pre3->execute();
                                        $ligne_pre3=$req_pre3->fetch(PDO::FETCH_OBJ);

                                        echo "<table><tr><td>".$ligne_pre2->CompetenceNom." :</td>";
                                        if(empty($ligne_pre3)){?>
                                            <form action="note.php" method="post">
                                            <td><input type="radio" name="<?php echo $value?>" value="1" /></td>
                                            <td><input type="radio" name="<?php echo $value?>" value="2" /></td>
                                            <td><input type="radio" name="<?php echo $value?>" value="3" /></td>
                                            <td><input type="radio" name="<?php echo $value?>" value="4" /></td>
                                            <td><input type="radio" name="<?php echo $value?>" value="5" /></td>
                                            <td><input type="submit"name="validation"value="Valider" /></td></tr>
                                            <tr><td></td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td></tr>
                                            </form>
                                            </table>
                                       <?php }else{}
                                    }
                                }else{echo "aucune";}
                            echo "<br> Compétences softskills : <br>";
                                if(!empty($compS[0])){
                                    foreach ($compS as $key => $value){
                                        
                                        $req_pre2 = $cnx->prepare("SELECT * FROM competences WHERE idCompetence = :id");

                                        $req_pre2->bindValue(':id', $value, PDO::PARAM_STR);
                                
                                        $req_pre2->execute();
                                        $ligne_pre2=$req_pre2->fetch(PDO::FETCH_OBJ);

                                        $req_pre3 = $cnx->prepare("SELECT * FROM notes WHERE idCompetence = :id AND login = :login");

                                        $req_pre3->bindValue(':id', $value, PDO::PARAM_STR);
                                        $req_pre3->bindValue(':login', $ligne->binome2, PDO::PARAM_STR);

                                        $req_pre3->execute();
                                        $ligne_pre3=$req_pre3->fetch(PDO::FETCH_OBJ);

                                        echo "<table><tr><td>".$ligne_pre2->CompetenceNom." :</td>";
                                        if(empty($ligne_pre3)){?>
                                            <form action="note.php" method="post">
                                            <td><input type="radio" name="<?php echo $ligne_pre2->CompetenceNom?>" value="1" /></td>
                                            <td><input type="radio" name="<?php echo $ligne_pre2->CompetenceNom?>" value="2" /></td>
                                            <td><input type="radio" name="<?php echo $ligne_pre2->CompetenceNom?>" value="3" /></td>
                                            <td><input type="radio" name="<?php echo $ligne_pre2->CompetenceNom?>" value="4" /></td>
                                            <td><input type="radio" name="<?php echo $ligne_pre2->CompetenceNom?>" value="5" /></td>
                                            <td><input type="submit"name="validation"value="Valider" /></td></tr>
                                            <tr><td></td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td></tr>
                                            </form>
                                            </table>
                                       <?php }else{}
                                    }
                                }else{echo "aucune";}
                                $ligne_req=$req->fetch(PDO::FETCH_OBJ);
                        }
                        echo "<br>";
                        
                    }else 
                    {
                        echo "<br><h3>".$ligne->libelleMatiere." : </h3>";

                        $req = $cnx->prepare("SELECT * FROM etudiants WHERE login = :login");

                        $req->bindValue(':login', $ligne->binome1, PDO::PARAM_STR);

                        $req->execute();
                        $ligne_req=$req->fetch(PDO::FETCH_OBJ);
                    
                        while ($ligne_req){
                            $compT = explode(',',$ligne_req->competencesTech);
                            $compS = explode(',',$ligne_req->competencesSoft);

                            echo "<h4>".$ligne_req->prenom." ".$ligne_req->nom." : </h4><br> Compétences techniques : <br>";
                                if(!empty($compT[0])){
                                    foreach ($compT as $key => $value){
                                        
                                        $req_pre2 = $cnx->prepare("SELECT * FROM competences WHERE idCompetence = :id");

                                        $req_pre2->bindValue(':id', $value, PDO::PARAM_STR);
                                
                                        $req_pre2->execute();
                                        $ligne_pre2=$req_pre2->fetch(PDO::FETCH_OBJ);

                                        $req_pre3 = $cnx->prepare("SELECT * FROM notes WHERE idCompetence = :id AND login = :login");

                                        $req_pre3->bindValue(':id', $value, PDO::PARAM_STR);
                                        $req_pre3->bindValue(':login', $ligne->binome2, PDO::PARAM_STR);

                                        $req_pre3->execute();
                                        $ligne_pre3=$req_pre3->fetch(PDO::FETCH_OBJ);

                                        echo "<table><tr><td>".$ligne_pre2->CompetenceNom." :</td>";
                                        if(empty($ligne_pre3)){?>
                                            <form action="note.php" method="post">
                                            <td><input type="radio" name="<?php echo $ligne_pre2->CompetenceNom?>" value="1" /></td>
                                            <td><input type="radio" name="<?php echo $ligne_pre2->CompetenceNom?>" value="2" /></td>
                                            <td><input type="radio" name="<?php echo $ligne_pre2->CompetenceNom?>" value="3" /></td>
                                            <td><input type="radio" name="<?php echo $ligne_pre2->CompetenceNom?>" value="4" /></td>
                                            <td><input type="radio" name="<?php echo $ligne_pre2->CompetenceNom?>" value="5" /></td>
                                            <td><input type="submit"name="validation"value="Valider" /></td></tr>
                                            <tr><td></td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td></tr>
                                            </form>
                                            </table>
                                       <?php }else{}
                                    }
                                }else{echo "aucune";}
                            echo "<br> Compétences softskills : <br>";
                                if(!empty($compS[0])){
                                    foreach ($compS as $key => $value){
                                        
                                        $req_pre2 = $cnx->prepare("SELECT * FROM competences WHERE idCompetence = :id");

                                        $req_pre2->bindValue(':id', $value, PDO::PARAM_STR);
                                
                                        $req_pre2->execute();
                                        $ligne_pre2=$req_pre2->fetch(PDO::FETCH_OBJ);

                                        $req_pre3 = $cnx->prepare("SELECT * FROM notes WHERE idCompetence = :id AND login = :login");

                                        $req_pre3->bindValue(':id', $value, PDO::PARAM_STR);
                                        $req_pre3->bindValue(':login', $ligne->binome2, PDO::PARAM_STR);

                                        $req_pre3->execute();
                                        $ligne_pre3=$req_pre3->fetch(PDO::FETCH_OBJ);

                                        echo "<table><tr><td>".$ligne_pre2->CompetenceNom." :</td>";
                                        if(empty($ligne_pre3)){?>
                                            <form action="note.php" method="post">
                                            <td><input type="radio" name="<?php echo $ligne_pre2->CompetenceNom?>" value="1" /></td>
                                            <td><input type="radio" name="<?php echo $ligne_pre2->CompetenceNom?>" value="2" /></td>
                                            <td><input type="radio" name="<?php echo $ligne_pre2->CompetenceNom?>" value="3" /></td>
                                            <td><input type="radio" name="<?php echo $ligne_pre2->CompetenceNom?>" value="4" /></td>
                                            <td><input type="radio" name="<?php echo $ligne_pre2->CompetenceNom?>" value="5" /></td>
                                            <td><input type="submit"name="validation"value="Valider" /></td></tr>
                                            <tr><td></td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td></tr>
                                            </form>
                                            </table>
                                       <?php }else{}
                                    }
                                }else{echo "aucune";}
                                
                                $ligne_req=$req->fetch(PDO::FETCH_OBJ);
                        }
                        echo "<br>";
                    }





                    $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
                }
            } 
        ?>
        <br>
     
    </body>
        </div>
</html>
<?php 
}else{
    header("Location: Connexion.php");}
?>
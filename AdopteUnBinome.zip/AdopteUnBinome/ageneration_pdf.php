<?php
session_start();
require('db-config.php');
require('db-connexion.php');
require('Deconnexion-admin.php');
require('fpdf.php');

class PDF extends FPDF
{
// En-tête
function Header()
{
    // Logo
    $this->Image('photos/logo.jpg',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(30,10,utf8_decode('Binômes'),1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}

function NomClasse($nom)
{
	// Arial 12
	$this->SetFont('Arial','',12);
	// Couleur de fond
	$this->SetFillColor(200,220,255);
	// Titre
	$this->Cell(0,6,$nom,0,1,'L',true);
	// Saut de ligne
	$this->Ln(4);
}

function Binomes($nom)
{
	// Arial 12
	$this->SetFont('Times','',12);
	// 
	$this->Cell(0,5,$nom);
	// Saut de ligne
	$this->Ln();
}


}
$req = $cnx->prepare("SELECT * FROM matieres");
$req->execute();
$ligne=$req->fetch(PDO::FETCH_OBJ);

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','',12);
while ($ligne){
    $pdf->NomClasse(utf8_decode($ligne->libelle));
    
     $req_pre = $cnx->prepare("SELECT * FROM binomes WHERE libelleMatiere = :matiere");
     $req_pre->bindValue(':matiere', $ligne->libelle, PDO::PARAM_STR);
     $req_pre->execute();
     $ligne2=$req_pre->fetch(PDO::FETCH_OBJ);
     if($ligne2){
         while($ligne2){
            $req_pre = $cnx->prepare("SELECT * FROM etudiants WHERE login = :login");
            $req_pre->bindValue(':login', $ligne2->binome1, PDO::PARAM_STR);
            $req_pre->execute();
            $binome1=$req_pre->fetch(PDO::FETCH_OBJ);
            $req_pre2 = $cnx->prepare("SELECT * FROM etudiants WHERE login = :login");
            $req_pre2->bindValue(':login', $ligne2->binome2, PDO::PARAM_STR);
            $req_pre2->execute();
            $binome2=$req_pre2->fetch(PDO::FETCH_OBJ);
            $pdf->Binomes(utf8_decode("Binôme 1 : ".$binome1->nom." ".$binome1->prenom." Binome 2 : ".$binome2->nom." ".$binome2->prenom));
                 
             $ligne2=$req_pre2->fetch(PDO::FETCH_OBJ);
         }
     }else{ $pdf->Binomes(utf8_decode("Aucun binôme dans cette matière"));}
     $ligne=$req->fetch(PDO::FETCH_OBJ);
 }

 $pdf->Output();
 
 ?>
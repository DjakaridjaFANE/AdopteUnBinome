<?php
session_start();
require('db-config.php');
require('db-connexion.php');


if(!empty($_POST['choix'])){
    $req_pre = $cnx->prepare("INSERT INTO demande(demandeur,destinataire,statut,libelleMatiere) VALUES(:login,:destinataire,'en attente',:matiere)");
                
    $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
    $req_pre->bindValue(':destinataire', $_POST['choix'], PDO::PARAM_STR);
    $req_pre->bindValue(':matiere', $_SESSION['matiere'], PDO::PARAM_STR);
                
    $req_pre->execute();
    echo "Demande envoyée !<p><a href='chercher.php'>Retour</a></p>";
        
}else{
    echo "Veuillez choisir un destinataire pour votre demande ! <p><a href='chercher.php'>Retour</a></p>";
}
$_SESSION['matiere']='';

?>
<?php
session_start();
require('db-config.php');
require('db-connexion.php');
require('Deconnexion-admin.php');
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Modifier les classes/matières</title>
    </head>
    <body><?php
        if ($_SESSION['ConnectAdmin']=true){
            if (isset ($_GET['action'])){
				if ($_GET['action'] == 'newclasse') 

				{ ?>
				<h2>Ajouter une classe</h2>
				<p>Sur cette page, vous pouvez ajouter une classe.

				<form method="post" action="valid_classes_matieres.php?action=newclasse" enctype="multipart/form-data">
				<table>
					<tr>
						<td>Libelle :</td>
						<td><input type='text' required name='libelleAjout' ></td>
					</tr>
    			
					<tr>
						<td></td>
						<td><input type='submit' value='Ajouter' /></td>
					</tr>
				</table>
				</form><?php
				}
				if ($_GET['action'] == 'newmatiere') 

				{ ?>
				<h2>Ajouter une matière</h2>
				<p>Sur cette page, vous pouvez ajouter une matière.

				<form method="post" action="valid_classes_matieres.php?action=newmatiere" enctype="multipart/form-data">
				<table>
					<tr>
						<td>Libelle :</td>
						<td><input type='text' required name='libelleAjout' ></td>
					</tr>
					<tr><td>Classe : </td><td>
                    <select required name="classeAjout"size="1">
                    <?php
                    $req_pre = $cnx->prepare("SELECT * FROM classes");
                    $req_pre->execute();
                    $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
                    while ($ligne){
                        echo "<option value=".$ligne->libelle.">".$ligne->libelle."</option>";
                        $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
                    } 
                    ?>
                    </select></td></tr>
					<tr>
						<td></td>
						<td><input type='submit' value='Ajouter' /></td>
					</tr>
				</table>
				</form><?php
				}
				if ($_GET['action'] == 'modifiermatiere'){ 
					$_SESSION['libelle'] = $_GET['libelle'];
					
					$req_pre = $cnx->prepare("SELECT * FROM matieres WHERE libelle = :libelle");
					
					$req_pre->bindValue(':libelle', $_GET['libelle'], PDO::PARAM_STR);
					$req_pre->execute();
					
					$utilisateur=$req_pre->fetch(PDO::FETCH_OBJ);
					?>

					<h2>Modifier matières</h2>
					<p>Sur cette page, vous pouvez modifier les matières existantes.

					<form method="post" action="valid_classes_matieres.php?action=modifiermatiere">
					<table>
						<tr>
							<td>Libelle :</td>
							<td><input type='text' name='libelleModifier' value='<?php echo $utilisateur->libelle; ?>'/></td>
						</tr>
						
						<tr><td>Classe : </td><td>
                    <select name="classeModifier"size="1">
                    <?php
                    $req_pre = $cnx->prepare("SELECT * FROM classes");
                    $req_pre->execute();
                    $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
                    while ($ligne){
                        echo "<option value=".$ligne->libelle.">".$ligne->libelle."</option>";
                        $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
                    } 
                    ?>
                    </select></td></tr>

						<tr>
							<td></td>
							<td><input type='submit' value='Modifier' /></td>
						</tr>
					</table>
					</form><?php 
				}
            }else {
				$resultat = $cnx->query("SELECT * FROM classes ");
					
				$resultat->setFetchMode(PDO::FETCH_OBJ);
					
				?>
				<h2>Classes</h2>
				<p>Vous pouvez ajouter ou supprimer des classes.<br>
				<a href="classes_matieres.php?action=newclasse">Ajouter une classe</a><br></p>
				
				<table>
				<tr>
					<td>libelle</td>
						
				</tr>

				<?php 
				$niveaux = $resultat->fetch();
				while ($niveaux) { ?>
					<tr>
					<td><?php echo $niveaux->libelle; ?></td>
					
					<td><a href='valid_classes_matieres.php?action=supprimerclasse&libelle=<?php echo $niveaux->libelle; ?>'>Supprimer</a></td>
					</tr>
					<?php 
					// lecture du niveaux suivant
					$niveaux = $resultat->fetch();
				}?></table><?php

					$resultat = $cnx->query("SELECT * FROM matieres ");
					
					$resultat->setFetchMode(PDO::FETCH_OBJ);
						
					?>
					<h2>Matières</h2>
					<p>Vous pouvez ajouter, modifier ou supprimer des matières.<br>
					<a href="classes_matieres.php?action=newmatiere">Ajouter une matière</a><br></p>
					
					<table>
					<tr>
						<td>libelle</td>
						<td>classe</td>
							
					</tr>
	
					<?php 
					$niveaux = $resultat->fetch();
					while ($niveaux) { ?>
						<tr>
						<td><?php echo $niveaux->libelle; ?></td>
						<td><?php echo $niveaux->classe; ?></td>
						<td><a href= 'classes_matieres.php?action=modifiermatiere&libelle=<?php echo  $niveaux->libelle;?>'>Modifier</a></td>
						<td><a href='valid_classes_matieres.php?action=supprimermatiere&libelle=<?php echo $niveaux->libelle; ?>'>Supprimer</a></td>
						</tr>
						<?php 
						// lecture du niveaux suivant
						$niveaux = $resultat->fetch();
				
				} ?>
				</table><?php
			}
			?><a href='accueil-admin.php'>Accueil</a><br><?php
	}else{
		header("Location: Connexion.php");}?>
	 	
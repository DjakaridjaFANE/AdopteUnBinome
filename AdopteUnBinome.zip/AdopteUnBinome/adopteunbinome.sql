CREATE TABLE IF NOT EXISTS classes (
    libelle VARCHAR(50) NOT NULL,
    CONSTRAINT pkClasses PRIMARY KEY(libelle)
) engine=INNODB ;
CREATE TABLE IF NOT EXISTS admin (
   idAdm int(3) NOT NULL AUTO_INCREMENT,
	login VARCHAR(50),
	password VARCHAR(100),
	email VARCHAR(100),
	CONSTRAINT PkAdm PRIMARY KEY(idAdm)
) engine=INNODB;
CREATE TABLE IF NOT EXISTS etudiants (
    login VARCHAR(50),
    nom VARCHAR(40),
    prenom VARCHAR(20),
    password VARCHAR(255),
    photo VARCHAR(255),
    libelleClasse VARCHAR(50),
    competencesTech VARCHAR(255),
    competencesSoft VARCHAR(255),
    CONSTRAINT pkEtudiants PRIMARY KEY(login),
    CONSTRAINT fkClasse FOREIGN KEY(libelleClasse) REFERENCES classes(libelle)
) engine=INNODB ;

CREATE TABLE IF NOT EXISTS competences (
    idCompetence INT(3) NOT NULL AUTO_INCREMENT,
    CompetenceType VARCHAR(1) ,
    CompetenceNom VARCHAR(50) ,
    CONSTRAINT pkCompetences PRIMARY KEY(idCompetence),
    -- 1 = Soft et 2 = Technique
    CONSTRAINT bool CHECK (CompetenceType = '1' OR CompetenceType = '2')
) engine=INNODB ;

CREATE TABLE IF NOT EXISTS notes (
    idNote INT(5) NOT NULL AUTO_INCREMENT,
    idCompetence INT(3),
    login VARCHAR(50),
    note INT(2),
    CONSTRAINT pkNotes PRIMARY KEY(idNote),
    CONSTRAINT fkEtudiants FOREIGN KEY (login) REFERENCES etudiants(login),
    CONSTRAINT fkCompetences FOREIGN KEY(idCompetence) REFERENCES competences(idCompetence)
) engine=INNODB ;

CREATE TABLE IF NOT EXISTS matieres (
    classe VARCHAR(50) NOT NULL,
    libelle VARCHAR(40) NOT NULL,
    CONSTRAINT pkMatieres PRIMARY KEY(libelle),
    CONSTRAINT fkClass FOREIGN KEY (classe) REFERENCES classes(libelle)
) engine=INNODB ;

CREATE TABLE IF NOT EXISTS demande (
    idDemande INT(3) NOT NULL AUTO_INCREMENT,
    demandeur VARCHAR(50),
    destinataire VARCHAR(50),
    statut VARCHAR(10),
    libelleMatiere VARCHAR(40),
    CONSTRAINT pkDemande PRIMARY KEY(idDemande)
) engine=INNODB ;


CREATE TABLE IF NOT EXISTS binomes (
    binome1 VARCHAR(50) NOT NULL,
    binome2 VARCHAR(50) NOT NULL,
    libelleMatiere VARCHAR(40) NOT NULL,
    CONSTRAINT pkBinomes PRIMARY KEY(binome1,binome2,libelleMatiere),
    CONSTRAINT fkMatiere FOREIGN KEY(libelleMatiere) REFERENCES matieres(libelle)
) engine=INNODB ;

CREATE TABLE IF NOT EXISTS statut (
    matiere VARCHAR(40) NOT NULL,
    login VARCHAR(50) NOT NULL,
    statut VARCHAR(1) NOT NULL,
    CONSTRAINT pkBinomes PRIMARY KEY(matiere,login),
    -- 1 = dispo et 2 = indispo
    CONSTRAINT bool CHECK (statut = '1' OR statut = '2')
) engine=INNODB ;


INSERT INTO competences (idCompetence, CompetenceType, CompetenceNom) VALUES
(1,2, 'Scala'),
(2,2,'Java'),
(3,2,'SQL'),
(4,2,'Bases de données'),
(5,2,'Python'),
(6,2,'PHP'),
(7,1,'Ouvert'),
(8,1,'Résolution de problèmes'),
(9,1,'Communication'),
(10,1,'Gestion du temps'),
(11,1,'Gestion du stress'),
(12,1,'Créativité'),
(13,1,'Motivation'),
(14,1,'Sens du collectif'),
(15,1,'Curiosité');

INSERT INTO admin (idAdm, login, password, email) VALUES
(1,'admin','admin','bertille.soriano@icloud.com');

INSERT INTO classes (libelle) VALUES
('L1'),
('L2'),
('L3');

INSERT INTO matieres (libelle, classe) VALUES
('COD','L1'),
('DIE','L1'),
('INF1','L1'),
('INF2','L1'),
('PPC','L1'),
('SEN1','L1'),
('SI1','L1'),
('SI2','L1'),
('CAL','L2'),
('DSB','L2'),
('GEN','L2'),
('OFI','L2'),
('PO','L2'),
('PW','L2'),
('RES','L2'),
('SEN2','L2'),
('BMO','L3'),
('CMPL','L3'),
('PFO','L3'),
('PGR','L3'),
('PGRC','L3'),
('RES2','L3'),
('SYS','L3'),
('Unix/C','L3');

INSERT INTO etudiants (login, nom, prenom, password, photo, libelleClasse, competencesTech, competencesSoft) VALUES
('bsoriano', 'Soriano', 'Bertille', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220',NULL,'L2',NULL,NULL);
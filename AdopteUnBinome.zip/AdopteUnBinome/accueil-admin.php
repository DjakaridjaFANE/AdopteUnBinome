<?php
require('Deconnexion-admin.php');
session_start();
if(isset($_GET['afaire']) && $_GET['afaire']=="deconnexion")
    {
		$_SESSION['ConnectAdmin']=false;
		session_destroy();
		header("Location: Connexion.php");
	}
?>

<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Accueil Admin</title>
    </head>
    <body>

        <?php
        if ($_SESSION['ConnectAdmin']=true)
        {?>
        
        Accueil <br>
       <br>
        <a href='comptes_admins.php'>Ajouter/Modifier/Supprimer comptes admins</a><br>
        <a href='comptes_etudiants.php'>Ajouter/Modifier/Supprimer comptes etudiants</a><br>
        <a href='afficher_demandes.php'>Afficher les demandes de binômes par matière</a><br>
        <a href='afficher_binomes.php'>Afficher les binômes par matière</a><br>
        <a href='ageneration_pdf.php'>PDF des binômes</a><br>  <br>
        <a href='classes_matieres.php'>Modifier les classes/ matières</a><br>
        



        <?php echo constant('DECO');
        ?>
    </body>
</html>
<?php 
}else{
    header("Location: Connexion.php");}
     ?>
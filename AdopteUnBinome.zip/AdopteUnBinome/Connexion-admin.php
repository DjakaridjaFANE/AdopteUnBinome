<?php
session_start();
$_SESSION['Connect']=false;
$_SESSION['ConnectAdmin']=false;
session_destroy();
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Connexion Admin</title>
    </head>
    <body>
        Connexion Admin
        <form action="valid_connexion-admin.php" method="post">
            <table>
                <tr><td>Login : </td><td><input type="text" name="login" size="20" /></td></tr>
                <tr><td>Mot de passe : </td><td><input type="password" name="password" size="20" /></td></tr>
                <tr><td><button type="submit" name="valider"><em>Se connecter</em></button></td></tr>
            </table>
        </form>
    </body>
</html>
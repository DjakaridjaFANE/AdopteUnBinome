<?php
session_start();
require('db-config.php');
require('db-connexion.php');
require('Deconnexion.php');
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Demandes de binômes</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/w3.css">
        <link rel="stylesheet" href="css/lato.css">
        <link rel="stylesheet" href="css/all.min.css">
    </head>
    <body>
        <!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a  href="Accueil.php"  class="w3-bar-item w3-button w3-padding-large"><i class="fa fa-home"></i></a>
    <a href="profil.php" class="w3-bar-item w3-button w3-padding-large">Profil</a>
    <a href="chercher.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Chercher un binôme</a>
    <a href="demandes.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Demandes de binômes</a>
    <a href="binomes.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Mes binômes</a>
    <a href="palmares.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Palmarès</a>
    <a href="accueil.php?afaire=deconnexion" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Déconnexion</a>
    <div class="w3-dropdown-hover w3-hide-small">
      <button class="w3-padding-large w3-button" title="More">MORE <i class="fa fa-caret-down"></i></button>     
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a href="#" class="w3-bar-item w3-button">Merchandise</a>
        <a href="#" class="w3-bar-item w3-button">Extras</a>
        <a href="#" class="w3-bar-item w3-button">Media</a>
      </div>
    </div>
    <a href="javascript:void(0)" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fa fa-search"></i></a>
  </div>
</div>

<div class="w3-content" style="max-width:2000px;margin-top:60px">
        <table>
            <form action="valid_demandes.php" method="post">
                <?php
                    if ($_SESSION['Connect'] == true){
                        $req = $cnx->prepare("SELECT * FROM demande WHERE destinataire = :login AND statut ='en attente'");
                        
                        $req->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);

                        $req->execute();
                        $ligne=$req->fetch(PDO::FETCH_OBJ);
                        if(!$ligne){echo "Pas de nouvelles demandes";}else{
                            while ($ligne){
                                $req_pre = $cnx->prepare("SELECT * FROM etudiants WHERE login = :login");
                                $req_pre->bindValue(':login', $ligne->demandeur, PDO::PARAM_STR);
                                $req_pre->execute();
                                $ligne2=$req_pre->fetch(PDO::FETCH_OBJ);
                                $compT = explode(',',$ligne2->competencesTech);
                                $compS = explode(',',$ligne2->competencesSoft);
                                ?>
                                <div class="w3-container">
                                 <div class="w3-card-4 w3-dark-grey" style="width:50%">

                                   <div class="w3-container w3-center">
                                     <h3><?php echo $ligne->libelleMatiere?></h3>
                                     <img src="<?php echo $ligne2->photo?>"  style="width:80%">
                                     <h5><?php echo $ligne2->prenom." ".$ligne2->nom?></h5>
                                     <h6>Compétences techniques : </h6><?php 
                                     if(!empty($compT[0])){
                                        foreach ($compT as $key => $value){
                                            
                                            $req_pre2 = $cnx->prepare("SELECT * FROM competences WHERE idCompetence = :id");
        
                                            $req_pre2->bindValue(':id', $value, PDO::PARAM_STR);
                                    
                                            $req_pre2->execute();
                                            $ligne_pre2=$req_pre2->fetch(PDO::FETCH_OBJ);
        
                                            echo $ligne_pre2->CompetenceNom."/";
                                        }
                                    }else{echo "aucune";}?>
                                     
                                    <h6>Compétences Softskills : <h6><?php 
                                     if(!empty($compS[0])){
                                        foreach ($compS as $key => $value){
                                            
                                            $req_pre2 = $cnx->prepare("SELECT * FROM competences WHERE idCompetence = :id");
        
                                            $req_pre2->bindValue(':id', $value, PDO::PARAM_STR);
                                    
                                            $req_pre2->execute();
                                            $ligne_pre2=$req_pre2->fetch(PDO::FETCH_OBJ);
        
                                            echo $ligne_pre2->CompetenceNom."/";
                                        }
                                    }else{echo "aucune";}?>

                                     <div class="w3-section">
                                       <button class="w3-button w3-green" name="<?php echo $ligne->idDemande?>" value='accepter'>Accepter</button>
                                       <button class="w3-button w3-red" name="<?php echo $ligne->idDemande?>" value='refuser'>Refuser</button>
                                     </div>
                                   </div>

                                 </div>
                                </div>
                                    <?php 
                                $ligne=$req->fetch(PDO::FETCH_OBJ);
                            }
                        } 
               
                ?>
     
            </form>
        </table>
    </body>
                    </div>
</html>
        <?php 
            }else{
            header("Location: Connexion.php");}
        ?>
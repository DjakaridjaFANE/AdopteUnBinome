<?php
session_start();
require('db-config.php');
require('db-connexion.php');

// préparation de la requête : recherche d'un utilisateur particulier
		$req_pre = $cnx->prepare("SELECT * FROM admin");
		$req_pre->execute();
		$req_pre->setFetchMode(PDO::FETCH_OBJ);
		//le résultat est récupéré sous forme d'objet
		$ligne=$req_pre->fetch();
		while ($ligne)
		{
			if($ligne->login == $_POST["login"])
			{
				
				$mdpbase = $ligne->password;
				$mdp = sha1($_POST['password']);
				if ($mdpbase == $mdp)
				{
					$_SESSION['login']=$_POST["login"];
					$_SESSION['mdp'] = $mdp;
					
                    $_SESSION['ConnectAdmin']=true;
                    header("Location: accueil-admin.php");
                }else{
					$logfile = fopen("Connexion-admin.php", "r");
                echo fread($logfile,filesize("Connexion-admin.php"))."Le mot de passe n'est pas correct <br>";
				fclose($logfile);
				}
               
			}
			else
			{
                $logfile = fopen("Connexion-admin.php", "r");
                echo fread($logfile,filesize("Connexion-admin.php"))."L'identifiant n'est pas correct <br>";
				fclose($logfile);
			}
			$ligne=$req_pre->fetch();
		}
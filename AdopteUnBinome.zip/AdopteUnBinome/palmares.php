<?php
session_start();
require('db-config.php');
require('db-connexion.php');
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Chercher un binôme</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/w3.css">
        <link rel="stylesheet" href="css/lato.css">
        <link rel="stylesheet" href="css/all.min.css">
    </head>
    <body>

        <!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a  href="Accueil.php"  class="w3-bar-item w3-button w3-padding-large"><i class="fa fa-home"></i></a>
    <a href="profil.php" class="w3-bar-item w3-button w3-padding-large">Profil</a>
    <a href="chercher.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Chercher un binôme</a>
    <a href="demandes.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Demandes de binômes</a>
    <a href="binomes.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Mes binômes</a>
    <a href="palmares.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Palmarès</a>
    <a href="accueil.php?afaire=deconnexion" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Déconnexion</a>
    <div class="w3-dropdown-hover w3-hide-small">
      <button class="w3-padding-large w3-button" title="More">MORE <i class="fa fa-caret-down"></i></button>     
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a href="#" class="w3-bar-item w3-button">Merchandise</a>
        <a href="#" class="w3-bar-item w3-button">Extras</a>
        <a href="#" class="w3-bar-item w3-button">Media</a>
      </div>
    </div>
    <a href="javascript:void(0)" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fa fa-search"></i></a>
  </div>
</div>
<div class="w3-content" style="max-width:2000px;margin-top:46px">
        <?php
            if ($_SESSION['Connect'] == true)
        {?>

     
    </body>

</html>
<?php 
}else{
    header("Location: Connexion.php");}
?>
<?php
session_start();
require('db-config.php');
require('db-connexion.php');
require('Deconnexion-admin.php');
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Gestion des comptes etudiants</title>
    </head>
    <body><?php
        if ($_SESSION['ConnectAdmin']=true){
            if (isset ($_GET['action'])){
				if ($_GET['action'] == 'modifiercompte'){ 
					$_SESSION['login'] = $_GET['idEt'];
                    echo $_SESSION['login'];
					
					$req_pre = $cnx->prepare("SELECT * FROM etudiants WHERE login = :login");
					
					$req_pre->bindValue(':login', $_GET['idEt'], PDO::PARAM_STR);
					$req_pre->execute();
					
					$utilisateur=$req_pre->fetch(PDO::FETCH_OBJ);
					?>

					<h2>Modifier compte etudiant</h2>
					<p>Sur cette page, vous pouvez modifier un compte existant.

					<form action="valid_comptes_etudiants.php?action=modifiercompte" method="post">
                <table>
                <tr><td>Nom : </td><td><input type="text" name='nomModifier' value="<?php echo $utilisateur->nom; ?>"" /></td></tr> 
                <tr><td>Prénom : </td><td><input type="text" name="prenomModifier" value="<?php echo $utilisateur->prenom; ?>"/></td></tr>
                <tr><td>Classe : </td><td>
                    <select name="classeModifier"size="1">
                    <?php
                    $req_pre = $cnx->prepare("SELECT * FROM classes");
                    $req_pre->execute();
                    $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
                    while ($ligne){
                        echo "<option value=".$ligne->libelle.">".$ligne->libelle."</option>";
                        $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
                    } 
                    ?>
                    </select></td></tr>
                <tr><td>Login : </td><td><input type="text" name="loginModifier" value="<?php echo $utilisateur->login; ?>" /></td></tr>
                <tr><td>Mot de passe : </td><td><input type="password" name="passwordModifier" minlength="4"  /></td></tr>
                <tr><td><button type="submit" name="valider"><em>Modifier</em></button></td></tr>
            </table>
        </form><?php 
				}
				if ($_GET['action'] == 'newcompte') 

				{ ?>
				<h2>Ajouter un compte etudiant</h2>
				<p>Sur cette page, vous pouvez ajouter un compte.

				<form action="valid_comptes_etudiants.php?action=newcompte" method="post">
                <table>
                <tr><td>Nom : </td><td><input type="text" required name="nomAjout"  /></td></tr> 
                <tr><td>Prénom : </td><td><input type="text" required name="prenomAjout"  /></td></tr>
                <tr><td>Classe : </td><td>
                    <select required name="classeAjout"size="1">
                    <?php
                    $req_pre = $cnx->prepare("SELECT * FROM classes");
                    $req_pre->execute();
                    $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
                    while ($ligne){
                        echo "<option value=".$ligne->libelle.">".$ligne->libelle."</option>";
                        $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
                    } 
                    ?>
                    </select></td></tr>
                <tr><td>Login : </td><td><input type="text" required name="loginAjout" size="20" /></td></tr>
                <tr><td>Mot de passe : </td><td><input type="password" name="passwordAjout" required minlength="4" size="20" /></td></tr>
                <tr><td><button type="submit" name="valider"><em>Ajouter</em></button></td></tr>
            </table>
        </form><?php
				}
            	}else {
					$resultat = $cnx->query("SELECT * FROM etudiants ");
					
					$resultat->setFetchMode(PDO::FETCH_OBJ);
					
					?>
					<h2>Comptes etudiants</h2>
					<p>A partir de cette page, vous pouvez ajouter, modifier ou supprimer des etudiants.<br>
					<a href="comptes_etudiants.php?action=newcompte">Ajouter un compte</a><br></p>
				
					<table class="table table-striped">
					<thead><tr class="success">
						<td>login</td>
                        <td>Nom</td>
                        <td>Prenom</td>
                        <td>Classe</td>
					</tr></thead>

					<?php 
					$niveaux = $resultat->fetch();
					while ($niveaux) { ?>
						<tr>
						<td><?php echo $niveaux->login; ?></td>
						<td><?php echo $niveaux->nom; ?></td>
                        <td><?php echo $niveaux->prenom; ?></td>
                        <td><?php echo $niveaux->libelleClasse; ?></td>
						<td><a href= 'comptes_etudiants.php?action=modifiercompte&idEt=<?php echo  $niveaux->login;?>'>Modifier</a></td>
						<td><a href='valid_comptes_etudiants.php?action=supprimercompte&idEt=<?php echo $niveaux->login; ?>'>Supprimer</a></td>
						</tr>
						<?php 
						// lecture du niveaux suivant
						$niveaux = $resultat->fetch();
					} ?>
					</table><?php
			}
			?><a href='accueil-admin.php'>Accueil</a><br><?php
		}else{
            header("Location: Connexion.php");}?>
	 	
<?php
session_start();
require('db-config.php');
require('db-connexion.php');
require('Deconnexion-admin.php');

if (isset ($_GET['action'])){
    if ($_GET['action'] == 'modifiercompte'){
        
        $req_pre = $cnx->prepare("SELECT password FROM etudiants WHERE login =:login");
        $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
        $req_pre->execute();
        $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
        if(sha1($_POST['passwordModifier']) != $ligne->password){
            $req_pre = $cnx->prepare("UPDATE etudiants SET password=:ps WHERE login =:login");

            $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
            $req_pre->bindValue(':ps', sha1($_POST['passwordModifier']), PDO::PARAM_STR);

            $req_pre->execute();
        }
        $req_pre = $cnx->prepare("SELECT nom FROM etudiants WHERE login =:login");
        $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
        $req_pre->execute();
        $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
        if($_POST['nomModifier'] != $ligne->nom){
            $req_pre = $cnx->prepare("UPDATE etudiants SET nom=:nom WHERE login =:login");

            $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
            $req_pre->bindValue(':nom', $_POST['nomModifier'], PDO::PARAM_STR);

            $req_pre->execute();
        }
        $req_pre = $cnx->prepare("SELECT prenom FROM etudiants WHERE login =:login");
        $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
        $req_pre->execute();
        $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
        if($_POST['prenomModifier'] != $ligne->prenom){
            $req_pre = $cnx->prepare("UPDATE etudiants SET prenom=:prenom WHERE login =:login");

            $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
            $req_pre->bindValue(':prenom', $_POST['prenomModifier'], PDO::PARAM_STR);

            $req_pre->execute();
        }
        $req_pre = $cnx->prepare("SELECT libelleClasse FROM etudiants WHERE login =:login");
        $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
        $req_pre->execute();
        $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
        if($_POST['classeModifier'] != $ligne->libelleClasse){
            $req_pre = $cnx->prepare("UPDATE etudiants SET libelleClasse=:classe WHERE login =:login");

            $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
            $req_pre->bindValue(':classe', $_POST['classeModifier'], PDO::PARAM_STR);

            $req_pre->execute();
        }
        if($_POST['loginModifier'] != $_SESSION['login']){
            $req_pre = $cnx->prepare("UPDATE etudiants SET login=:newlogin WHERE login =:login");
            $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
            $req_pre->bindValue(':newlogin', $_POST['loginModifier'], PDO::PARAM_STR);
            $req_pre->execute();

            $req_pre = $cnx->prepare("UPDATE binomes SET login=:newlogin WHERE login =:login");
            $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
            $req_pre->bindValue(':newlogin', $_POST['loginModifier'], PDO::PARAM_STR);
            $req_pre->execute();
            
            $req_pre = $cnx->prepare("UPDATE statut SET login=:newlogin WHERE login =:login");
            $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
            $req_pre->bindValue(':newlogin', $_POST['loginModifier'], PDO::PARAM_STR);
            $req_pre->execute();
            
            $req_pre = $cnx->prepare("UPDATE demande SET login=:newlogin WHERE login =:login");
            $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
            $req_pre->bindValue(':newlogin', $_POST['loginModifier'], PDO::PARAM_STR);
            $req_pre->execute();
            
        }
        header("Location: comptes_etudiants.php");

	}
    if ($_GET['action'] == 'newcompte')
	{
        $req = $cnx->prepare("SELECT * FROM etudiants");
        $req->execute();
        $req->setFetchMode(PDO::FETCH_OBJ);
        $ligne=$req->fetch();
        $canAdd = true;
        while ($ligne){
            if($_POST['loginAjout']==$ligne->login){
                echo "Le login est déjà pris <br>
                <a href='valid_comptes_etudiants.php?action=newcompte'>Retour</a>";
                $canAdd = false;
            }
            $ligne=$req->fetch();
        }
        if ( $canAdd == true ){
            $req_pre = $cnx->prepare("INSERT INTO etudiants(login ,prenom, nom, password, libelleClasse) VALUES(:login, :prenom, :nom , :password, :classe)");
            $req_pre->bindValue(':login', $_POST['loginAjout'], PDO::PARAM_STR);
            $req_pre->bindValue(':prenom', $_POST['prenomAjout'], PDO::PARAM_STR);
            $req_pre->bindValue(':nom', $_POST['nomAjout'], PDO::PARAM_STR);
            $req_pre->bindValue(':password', sha1($_POST['passwordAjout']), PDO::PARAM_STR);
            $req_pre->bindValue(':classe', $_POST['classeAjout'], PDO::PARAM_STR);
            $req_pre->execute();

            $req2 = $cnx->prepare("SELECT * FROM matieres WHERE classe= :classe");
            $req2->bindValue(':classe', $_POST['classeAjout'], PDO::PARAM_STR);
            $req2->execute();
            $req2->setFetchMode(PDO::FETCH_OBJ);
            
            $ligne2=$req2->fetch();
        
            while ($ligne2)
            {
                //toutes les matières ont comme statut indisponible par default
                $req_pre2 = $cnx->prepare("INSERT INTO statut(matiere,login, statut) VALUES(:matiere, :login, 2)");
                $req_pre2->bindValue(':login', $_POST['loginAjout'], PDO::PARAM_STR);
                $req_pre2->bindValue(':matiere', $ligne2->libelle, PDO::PARAM_STR);
                $req_pre2->execute();
            
                $ligne2=$req2->fetch();
            }
            header("Location: comptes_etudiants.php");
        }
    }
	
	if ($_GET['action'] == 'supprimercompte')
	{
		$req_pre = $cnx->prepare("DELETE FROM etudiants WHERE login = :login");
	
		$req_pre->bindValue(':login', $_GET['idEt'], PDO::PARAM_STR);
		$req_pre->execute();
		
        $req_pre = $cnx->prepare("DELETE FROM binomes WHERE  binome1 = :login OR binome2 = :login");
        $req_pre->bindValue(':login', $_GET['idEt'], PDO::PARAM_STR);
		$req_pre->execute();

        $req_pre = $cnx->prepare("UPDATE demande SET statut='annulée' WHERE destinataire = :login OR demandeur = :login");
        $req_pre->bindValue(':login', $_GET['idEt'], PDO::PARAM_STR);
		$req_pre->execute();

        $req_pre = $cnx->prepare("DELETE FROM statut WHERE login = :login");
        $req_pre->bindValue(':login', $_GET['idEt'], PDO::PARAM_STR);
		$req_pre->execute();
        header("Location: comptes_etudiants.php");
	}
}
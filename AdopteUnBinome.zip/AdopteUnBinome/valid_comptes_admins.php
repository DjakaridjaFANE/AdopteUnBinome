<?php
session_start();
require('db-config.php');
require('db-connexion.php');
require('Deconnexion-admin.php');

if (isset ($_GET['action'])){
    if ($_GET['action'] == 'modifiercompte'){
        if(!empty($_POST['loginModifier'])){
            $req_pre = $cnx->prepare("UPDATE admin SET login=:login WHERE idAdm =:id");

            $req_pre->bindValue(':id', $_SESSION['id'], PDO::PARAM_INT);
            $req_pre->bindValue(':login', $_POST['loginModifier'], PDO::PARAM_STR);

            $req_pre->execute();
        }
        if(!empty($_POST['passwordModifier'])){
            $req_pre = $cnx->prepare("UPDATE admin SET password=:ps WHERE idAdm =:id");

            $req_pre->bindValue(':id', $_SESSION['id'], PDO::PARAM_INT);
            $req_pre->bindValue(':ps', sha1($_POST['passwordModifier']), PDO::PARAM_STR);

            $req_pre->execute();
        }
        header("Location: comptes_admins.php");

	}
    if ($_GET['action'] == 'newcompte')
	{
		
		$req_pre = $cnx->prepare("INSERT INTO admin(login, password) VALUES(:login, :password)");
		
		$req_pre->bindValue(':login', $_POST['loginAjout'], PDO::PARAM_STR);
		$req_pre->bindValue(':password', sha1($_POST['passwordAjout']), PDO::PARAM_STR);
		$req_pre->execute();
		
		header("Location: comptes_admins.php");
	}
	
	if ($_GET['action'] == 'supprimercompte')
	{
		
		$req_pre = $cnx->prepare("DELETE FROM admin WHERE idAdm = :id");
	
		$req_pre->bindValue(':id', $_GET['idAdm'], PDO::PARAM_INT);
		$req_pre->execute();
		
        header("Location: comptes_admins.php");
	}
}
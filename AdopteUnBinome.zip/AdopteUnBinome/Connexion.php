<?php
session_start();
$_SESSION['Connect']=false;
$_SESSION['ConnectAdmin']=false;
session_destroy();
?>

<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Connexion</title>
        <link rel="stylesheet" href="css/w3.css">
        <link rel="stylesheet" href="css/lato.css">
        <link rel="stylesheet" href="css/all.min.css">
    </head>
    <body>
        Connexion 
        <a href='Inscription.php'>Inscription</a><br>
        <form action="valid_connexion.php" method="post">
            <table>
                <tr><td>Login : </td><td><input type="text" name="login" size="20" /></td></tr>
                <tr><td>Mot de passe : </td><td><input type="password" name="password" size="20" /></td></tr>
                <tr><td><button type="submit" name="valider"><em>Se connecter</em></button></td></tr>
            </table>
        </form>
        <a href='Connexion-admin.php'>Connexion admin</a><br>
    </body>
</html>
<?php echo $_SESSION['Connect'];?>
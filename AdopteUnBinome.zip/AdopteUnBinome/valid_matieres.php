<?php
session_start();
require('db-config.php');
require('db-connexion.php');
if(!empty($_POST['statut'])){
    $req_pre = $cnx->prepare("UPDATE statut SET statut = :statut WHERE login = :login AND matiere = :matiere");

    $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
    $req_pre->bindValue(':matiere', $_POST['matiere'], PDO::PARAM_STR);
    $req_pre->bindValue(':statut', $_POST['statut'], PDO::PARAM_STR);

    $req_pre->execute();
    
    header("Location: profil.php");

}else{
    header("Location: profil.php");
}?>
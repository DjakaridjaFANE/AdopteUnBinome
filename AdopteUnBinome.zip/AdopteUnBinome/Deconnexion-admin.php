<?php
define('DECO', "<!DOCTYPE html>
<html>
<body>
<p><a href='accueil-admin.php?afaire=deconnexion'>Déconnexion</a></p>
</body>
</html>");
?>
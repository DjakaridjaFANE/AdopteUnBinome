<?php
session_start();
require('db-config.php');
require('db-connexion.php');
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Profil</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/w3.css">
        <link rel="stylesheet" href="css/lato.css">
        <link rel="stylesheet" href="css/all.min.css">
    </head>
    <body>
        <!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a  href="Accueil.php"  class="w3-bar-item w3-button w3-padding-large"><i class="fa fa-home"></i></a>
    <a href="profil.php" class="w3-bar-item w3-button w3-padding-large">Profil</a>
    <a href="chercher.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Chercher un binôme</a>
    <a href="demandes.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Demandes de binômes</a>
    <a href="binomes.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Mes binômes</a>
    <a href="palmares.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Palmarès</a>
    <a href="accueil.php?afaire=deconnexion" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Déconnexion</a>
    <div class="w3-dropdown-hover w3-hide-small">
      <button class="w3-padding-large w3-button" title="More">MORE <i class="fa fa-caret-down"></i></button>     
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a href="#" class="w3-bar-item w3-button">Merchandise</a>
        <a href="#" class="w3-bar-item w3-button">Extras</a>
        <a href="#" class="w3-bar-item w3-button">Media</a>
      </div>
    </div>
    <a href="javascript:void(0)" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fa fa-search"></i></a>
  </div>
</div>

<!-- body entouré de la class eq contenu-->
<div class="w3-content" style="max-width:2000px;margin-top:46px">
<body>
        <?php
            if ($_SESSION['Connect'] == true)
        {?>
        <table>
            <tr><td>Nom : </td><td><?php echo $_SESSION['Prenom']; ?></td></tr> 
            <tr><td>Prénom : </td><td><?php echo $_SESSION['Nom']; ?></td></tr>
            <tr><td>Photo : </td><td></td>
            <!--   <form action="upload.php" method="post" enctype="multipart/form-data">
        Select Image File to Upload:
      <input type="file" name="file">
      <input type="submit" name="submit" value="Upload">
  </form>-->
            <form action="valid_photos.php" method="post" type="multipart/form-data">
            <td><input type ="file" name ="photo"></td>
            <td><input type='submit' name="submit" value='Ajouter' /></td></form></tr>
            <tr><td>Compétences : </td><td></td></tr>
            <form action="valid_competences.php" method="post">
                <tr><td>Compétences techniques :</td><td>
                    <?php
                        $req_pre = $cnx->prepare("SELECT * FROM competences WHERE CompetenceType = 2");
                        $req_pre->execute();
                        $ligne_req=$req_pre->fetch(PDO::FETCH_OBJ);
                        while ($ligne_req){
                            echo "<br><input type='checkbox' name='competencesTech[]' value='".$ligne_req->idCompetence."'/>".$ligne_req->CompetenceNom;
                            $ligne_req=$req_pre->fetch(PDO::FETCH_OBJ);
                        } 
                    ?>
                </td>
                <td>Compétences softskills :</td><td>
                    <?php
                        $req_pre = $cnx->prepare("SELECT * FROM competences WHERE CompetenceType = 1");
                        $req_pre->execute();
                        $ligne_req=$req_pre->fetch(PDO::FETCH_OBJ);
                        while ($ligne_req){
                            echo "<br><input type='checkbox' name='competencesSoft[]' value='".$ligne_req->idCompetence."'/>".$ligne_req->CompetenceNom;
                            $ligne_req=$req_pre->fetch(PDO::FETCH_OBJ);
                        } 
                    ?>
                </td>
                <tr><td><button type="submit" name="valider"><em>Valider</em></button></td></tr>
            </form>
            <tr><td> Statut par matières : </td><td>
            <form action="valid_matieres.php" method="post">
            <select name="matiere"size="1">
                <?php
                $req_pre = $cnx->prepare("SELECT etudiants.login, matieres.libelle FROM classes,matieres,etudiants,binomes WHERE etudiants.login = :login AND classes.libelle = etudiants.libelleClasse AND classes.libelle = matieres.classe AND matieres.libelle NOT IN ( SELECT binomes.libelleMatiere from binomes WHERE binome1 = :login OR binome2 =:login )   GROUP BY matieres.libelle;");
                $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
                $req_pre->execute();
                $ligne_req=$req_pre->fetch(PDO::FETCH_OBJ);
                while ($ligne_req){
                          echo "<option value=".$ligne_req->libelle.">".$ligne_req->libelle."</option>";
                          $ligne_req=$req_pre->fetch(PDO::FETCH_OBJ);
                    }
                    
                     ?></tr><tr>
                            <td><input type ="radio" name="statut" value="2"/>Indisponible<br></td>
                            <td><input type ="radio" name="statut" value="1"/>Disponible<br></td>
                            
                    </select></tr>
                <tr><td><button type="submit" name="valider"><em>Valider</em></button></td></tr>
            </form>
        </table>
       

     
    </body>
    <div class="w3-content" style="max-width:2000px;margin-top:46px">
</html>
<?php 
}else{
    header("Location: Connexion.php");}
?>


<?php
    require('db-config.php');
    require('db-connexion.php');
    session_start(); 
    
    $req = $cnx->prepare("SELECT * FROM etudiants");
    $req->execute();
    $req->setFetchMode(PDO::FETCH_OBJ);
    //le résultat est récupéré sous forme d'objet
    $ligne=$req->fetch();
    $canAdd = true;
    while ($ligne)
    {
        if($_POST['login']==$ligne->login)
        {
            echo "Le login est déjà pris <br>
            <a href='Inscription.php'>Retour</a>";
            $canAdd = false;
        }
        $ligne=$req->fetch();
    }
    if ( $canAdd == true )
    {
        
        $req_pre = $cnx->prepare("INSERT INTO etudiants(login ,prenom, nom, password, libelleClasse) VALUES(:login, :prenom, :nom , :password, :classe)");
       
            
        $req_pre->bindValue(':login', $_POST['login'], PDO::PARAM_STR);
        $req_pre->bindValue(':prenom', $_POST['prenom'], PDO::PARAM_STR);
        $req_pre->bindValue(':nom', $_POST['nom'], PDO::PARAM_STR);
        $req_pre->bindValue(':password', sha1($_POST['password']), PDO::PARAM_STR);
        $req_pre->bindValue(':classe', $_POST['classe'], PDO::PARAM_STR);
        
        $req_pre->execute();

        $req2 = $cnx->prepare("SELECT * FROM matieres WHERE classe= :classe");
        $req2->bindValue(':classe', $_POST['classe'], PDO::PARAM_STR);
        $req2->execute();
        $req2->setFetchMode(PDO::FETCH_OBJ);
        
        $ligne2=$req2->fetch();
    
        while ($ligne2)
        {
            //toutes les matières ont comme statut indisponible par default
            $req_pre2 = $cnx->prepare("INSERT INTO statut(matiere,login, statut) VALUES(:matiere, :login, 2)");
            $req_pre2->bindValue(':login', $_POST['login'], PDO::PARAM_STR);
            $req_pre2->bindValue(':matiere', $ligne2->libelle, PDO::PARAM_STR);
            $req_pre2->execute();
        
            $ligne2=$req2->fetch();
        }

        header("Location: Connexion.php");
    }
    ?>
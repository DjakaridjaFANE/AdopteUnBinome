<?php
session_start();
require('db-config.php');
require('db-connexion.php');
$req = $cnx->prepare("SELECT * FROM notes WHERE idCompetence = :comp");

$req->bindValue(':comp', $_POST[], PDO::PARAM_STR);

$req->execute();
$ligne_req=$req->fetch(PDO::FETCH_OBJ);
}?>                    
<?php
require('db-config.php');
require('db-connexion.php');
session_start();
$_SESSION['Connect']=false;
$_SESSION['ConnectAdmin']=false;
session_destroy();
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Inscription</title>
        <link rel="stylesheet" href="css/w3.css">
        <link rel="stylesheet" href="css/lato.css">
        <link rel="stylesheet" href="css/all.min.css">
    </head>
    <body>
        <a href='Connexion.php'>Connexion</a>
        Inscription <br>
        <form action="valid_inscription.php" method="post">
            <table>
                <tr><td>Nom : </td><td><input type="text" required name="nom" size="20" /></td></tr> 
                <tr><td>Prénom : </td><td><input type="text" required name="prenom" size="20" /></td></tr>
                <tr><td>Classe : </td><td>
                    <select required name="classe"size="1">
                    <?php
                    $req_pre = $cnx->prepare("SELECT * FROM classes");
                    $req_pre->execute();
                    $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
                    while ($ligne){
                        echo "<option value=".$ligne->libelle.">".$ligne->libelle."</option>";
                        $ligne=$req_pre->fetch(PDO::FETCH_OBJ);
                    } 
                    ?>
                    </select></td></tr>
                <tr><td>Login : </td><td><input type="text" required name="login" size="20" /></td></tr>
                <tr><td>Mot de passe : </td><td><input type="password" name="password" required minlength="4" size="20" /></td></tr>
                <tr><td><button type="submit" name="valider"><em>S'inscrire</em></button></td></tr>
            </table>
        </form>
    </body>
</html>

<?php
        
        
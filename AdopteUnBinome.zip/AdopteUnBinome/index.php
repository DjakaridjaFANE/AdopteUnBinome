<?php

if(isset($_SESSION['Connect'])){
    if($_SESSION['Connect']=false){
        header("location : Connexion.php");
    }elseif($_SESSION['Connect']=true){
        header("location : Accueil.php");
    }
}else{header("location : Connexion.php");}
?>
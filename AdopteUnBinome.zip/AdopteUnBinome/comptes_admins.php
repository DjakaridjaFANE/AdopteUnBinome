<?php
session_start();
require('db-config.php');
require('db-connexion.php');
require('Deconnexion-admin.php');
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Gestion des comptes admin</title>
    </head>
    <body><?php
        if ($_SESSION['ConnectAdmin']=true){
            if (isset ($_GET['action'])){
				if ($_GET['action'] == 'modifiercompte'){ 
					$_SESSION['id'] = $_GET['idAdm'];
					
					$req_pre = $cnx->prepare("SELECT * FROM admin WHERE idAdm = :id");
					
					$req_pre->bindValue(':id', $_GET['idAdm'], PDO::PARAM_INT);
					$req_pre->execute();
					
					$utilisateur=$req_pre->fetch(PDO::FETCH_OBJ);
					?>

					<h2>Modifier compte admin</h2>
					<p>Sur cette page, vous pouvez modifier un compte existant.

					<form method="post" action="valid_comptes_admins.php?action=modifiercompte">
					<table>
						<tr>
							<td>Login :</td>
							<td><input type='text' name='loginModifier' value='<?php echo $utilisateur->login; ?>'/></td>
						</tr>
						
						<tr>
							<td>Mot de passe :</td>
							<td><input type='password' name='passwordModifier' value=''/></td>
						</tr>

						<tr>
							<td></td>
							<td><input type='submit' value='Modifier' /></td>
						</tr>
					</table>
					</form><?php 
				}
				if ($_GET['action'] == 'newcompte') 

				{ ?>
				<h2>Ajouter un compte admin</h2>
				<p>Sur cette page, vous pouvez ajouter un compte.

				<form method="post" action="valid_comptes_admins.php?action=newcompte" enctype="multipart/form-data">
				<table>
					<tr>
						<td>login :</td>
						<td><input type='text' required name='loginAjout' ></td>
					</tr>
					<tr>
    				  	<td>mot de passe :</td>
						<td><input type='text' required name='passwordAjout'></td>
					</tr>
    			
					<tr>
						<td></td>
						<td><input type='submit' value='Ajouter' /></td>
					</tr>
				</table>
				</form><?php
				}
            	}else {
					$resultat = $cnx->query("SELECT * FROM admin ");
					
					$resultat->setFetchMode(PDO::FETCH_OBJ);
					
					?>
					<h2>Comptes admin</h2>
					<p>A partir de cette page, vous pouvez ajouter, modifier ou supprimer des admins.<br>
					<a href="comptes_admins.php?action=newcompte">Ajouter un compte</a><br></p>
				
					<table class="table table-striped">
					<thead><tr class="success">
						<td>login</td>
						
					</tr></thead>

					<?php 
					$niveaux = $resultat->fetch();
					while ($niveaux) { ?>
						<tr>
						<td><?php echo $niveaux->login; ?></td>
						
						<td><a href= 'comptes_admins.php?action=modifiercompte&idAdm=<?php echo  $niveaux->idAdm;?>'>Modifier</a></td>
						<td><a href='valid_comptes_admins.php?action=supprimercompte&idAdm=<?php echo $niveaux->idAdm; ?>'>Supprimer</a></td>
						</tr>
						<?php 
						// lecture du niveaux suivant
						$niveaux = $resultat->fetch();
					} ?>
					</table><?php
			}
			?><a href='accueil-admin.php'>Accueil</a><br><?php
		}else{
			header("Location: Connexion.php");}?>
	 	
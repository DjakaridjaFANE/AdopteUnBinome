<?php
session_start();
require('db-config.php');
require('db-connexion.php');
$compT = "";
$compS = "";
$req = $cnx->prepare("SELECT * FROM etudiants WHERE login =:login");
$req->bindValue(':login', $_SESSION["login"], PDO::PARAM_STR);
$req->execute();
$req->setFetchMode(PDO::FETCH_OBJ);
$ligne=$req->fetch();
while ($ligne){
    $compT = $ligne->competencesTech;
    $compS = $ligne->competencesSoft;
    $ligne=$req->fetch(PDO::FETCH_OBJ);
}
if(!empty($_POST['competencesTech'])){
    foreach ($_POST['competencesTech'] as $key => $value) {
        if(empty($compT)){
            $compT = $compT.$value;
        }else{
            $compT = $compT.",".$value;
        }
    }
}
if(!empty($_POST['competencesSoft'])){
    foreach ($_POST['competencesSoft'] as $key => $value) {
        if(empty($compS)){
            $compS = $compS.$value;
        }else{
            $compS = $compS.",".$value;
        }
    }
}
$req_pre = $cnx->prepare("UPDATE etudiants SET competencesTech = :compT, competencesSoft = :compS WHERE login = :login");
$req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
$req_pre->bindValue(':compT', $compT, PDO::PARAM_STR);
$req_pre->bindValue(':compS', $compS, PDO::PARAM_STR);
$req_pre->execute();

header("Location: profil.php");
?>
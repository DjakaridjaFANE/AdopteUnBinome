<?php
session_start();
require('db-config.php');
require('db-connexion.php');
require('Deconnexion.php');
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Chercher un binôme</title>
        <link rel="stylesheet" href="css/w3.css">
        <link rel="stylesheet" href="css/lato.css">
        <link rel="stylesheet" href="css/all.min.css">
    </head>
            <!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a  href="Accueil.php"  class="w3-bar-item w3-button w3-padding-large"><i class="fa fa-home"></i></a>
    <a href="profil.php" class="w3-bar-item w3-button w3-padding-large">Profil</a>
    <a href="chercher.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Chercher un binôme</a>
    <a href="demandes.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Demandes de binômes</a>
    <a href="binomes.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Mes binômes</a>
    <a href="palmares.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Palmarès</a>
    <a href="accueil.php?afaire=deconnexion" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Déconnexion</a>
    <div class="w3-dropdown-hover w3-hide-small">
      <button class="w3-padding-large w3-button" title="More">MORE <i class="fa fa-caret-down"></i></button>     
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a href="#" class="w3-bar-item w3-button">Merchandise</a>
        <a href="#" class="w3-bar-item w3-button">Extras</a>
        <a href="#" class="w3-bar-item w3-button">Media</a>
      </div>
    </div>
    <a href="javascript:void(0)" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fa fa-search"></i></a>
  </div>
</div>
<div class="w3-content" style="max-width:2000px;margin-top:46px">
    <body><?php
    if ($_SESSION['Connect'] == true){
        if(!empty($_POST['matiere'])){
            $_SESSION['matiere']= $_POST['matiere'];
            $req = $cnx->prepare("SELECT * FROM statut WHERE matiere = :matiere AND statut = '1' AND login NOT LIKE :log");

            $req->bindValue(':matiere', $_POST['matiere'], PDO::PARAM_STR);
            $req->bindValue(':log', $_SESSION['login'], PDO::PARAM_STR);

            $req->execute();
            $ligne=$req->fetch(PDO::FETCH_OBJ);
            if(!$ligne){echo 'Aucun résultat ! <p><a href="chercher.php">Retour</a></p>';}else{?>
                <table>
                <form action="envoi_demande.php" method="post"> 
               
                <?php
                while ($ligne){
                    $req2 = $cnx->prepare("SELECT * FROM etudiants WHERE login = :login");

                    $req2->bindValue(':login', $ligne->login, PDO::PARAM_STR);

                    $req2->execute();
                    $ligne2=$req2->fetch(PDO::FETCH_OBJ);
                   
                    while ($ligne2){

                        $req_pre = $cnx->prepare("SELECT * FROM demande WHERE demandeur = :login AND destinataire = :destinataire AND libelleMatiere = :matiere");

                        $req_pre->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
                        $req_pre->bindValue(':destinataire', $ligne2->login, PDO::PARAM_STR);
                        $req_pre->bindValue(':matiere', $_POST['matiere'], PDO::PARAM_STR);

                        $req_pre->execute();
                        $ligne_pre=$req_pre->fetch(PDO::FETCH_OBJ);
                        
                        $compT = explode(',',$ligne2->competencesTech);
                        $compS = explode(',',$ligne2->competencesSoft);
                        
                        // si il existe une demande
                        if($ligne_pre){
                            echo "<tr><td>".$ligne2->prenom." ".$ligne2->nom." : <br> Compétences techniques : ";
                            if(!empty($compT[0])){
                                foreach ($compT as $key => $value){
                                    
                                    $req_pre2 = $cnx->prepare("SELECT * FROM competences WHERE idCompetence = :id");

                                    $req_pre2->bindValue(':id', $value, PDO::PARAM_STR);
                            
                                    $req_pre2->execute();
                                    $ligne_pre2=$req_pre2->fetch(PDO::FETCH_OBJ);

                                    echo $ligne_pre2->CompetenceNom."/";
                                }
                            }else{echo "aucune";}
                            echo "<br> Compétences Softskills : ";
                            if(!empty($compS[0])){
                                foreach ($compS as $key => $value){
                                    $req_pre2 = $cnx->prepare("SELECT * FROM competences WHERE idCompetence = :id");

                                    $req_pre2->bindValue(':id', $value, PDO::PARAM_STR);
                            
                                    $req_pre2->execute();
                                    $ligne_pre2=$req_pre2->fetch(PDO::FETCH_OBJ);

                                    echo $ligne_pre2->CompetenceNom."/";
                                }
                            }else{echo "aucune";}
                            echo "</td>";
                            echo "<td>Demande déjà envoyée</td></tr>";
                        }else{
                            echo "<tr><td>".$ligne2->prenom." ".$ligne2->nom." : <br> Compétences techniques : ";
                            if(!empty($compT[0])){
                                foreach ($compT as $key => $value){
                                    $req_pre2 = $cnx->prepare("SELECT * FROM competences WHERE idCompetence = :id");

                                    $req_pre2->bindValue(':id', $value, PDO::PARAM_STR);
                            
                                    $req_pre2->execute();
                                    $ligne_pre2=$req_pre2->fetch(PDO::FETCH_OBJ);

                                    echo $ligne_pre2->CompetenceNom."/";
                                }
                            }else{echo "aucune";}
                            echo "<br> Compétences Softskills : ";
                            if(!empty($compS[0])){
                                foreach ($compS as $key => $value){
                                    $req_pre2 = $cnx->prepare("SELECT * FROM competences WHERE idCompetence = :id");

                                    $req_pre2->bindValue(':id', $value, PDO::PARAM_STR);
                            
                                    $req_pre2->execute();
                                    $ligne_pre2=$req_pre2->fetch(PDO::FETCH_OBJ);

                                    echo $ligne_pre2->CompetenceNom."/";
                                }
                            }else{echo "aucune";}
                            echo "</td>";                            
                            echo "<td><input type='radio' name='choix' value='".$ligne2->login."' /></td></tr>";
                        }
                        $ligne2=$req2->fetch(PDO::FETCH_OBJ);
                    }
                    $ligne=$req->fetch(PDO::FETCH_OBJ);
                }
            }?>
             <tr><td><button type="submit" name="demander"><em>Envoyer une demande</em></button></td></tr>
                </form>
            </table>
    </body>
        </div>
</html>
<?php 
        }else{
            echo "Veuillez choisir une matière ! <p><a href='chercher.php'>Retour</a></p>";}
    }else{
        header("Location: Connexion.php");
    }?>




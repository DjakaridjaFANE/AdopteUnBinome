<?php
session_start();
require('db-config.php');
require('db-connexion.php');
/* 
$req_pre = $cnx->prepare("UPDATE etudiants SET photo = :photopath WHERE login = :login");
$req_pre->bindValue(':login', $_SESSION["login"], PDO::PARAM_STR);
$req_pre->bindValue(':photopath', $_POST['photo'], PDO::PARAM_STR);
$req_pre->execute(); */
$statusMsg = '';
$backlink = ' <a href="./">Go back</a>';

// File upload path
$targetDir = "photos/";
printr_($_POST);
print_r($_FILES);
$fileName = basename($_FILES["file"]["name"]);
$targetFilePath = $targetDir . $fileName;
$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

if(isset($_POST["submit"]) && !empty($_FILES["file"]["name"])){
    // Allow certain file formats
    $allowTypes = array('jpg','png','jpeg','gif');
    in_array($fileType, $allowTypes)
    // Upload file to server
    move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)
    $insert = $db->query("INSERT into etudiants ('photo') VALUES ('".$fileName."'");



//header("Location: profil.php");
?>
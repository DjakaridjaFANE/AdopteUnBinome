<?php
session_start();
require('db-config.php');
require('db-connexion.php');

		$req_pre = $cnx->prepare("SELECT * FROM etudiants");
		$req_pre->execute();
		$ligne=$req_pre->fetch(PDO::FETCH_OBJ);

		print_r($_POST);
		while ($ligne)
		{
			if($ligne->login == $_POST['login'])
			{
				$mdpbase = $ligne->password;
				$mdp = sha1($_POST['password']);
				if ($mdpbase == $mdp)
				{
					$_SESSION['login']= $_POST['login'];
					$_SESSION['mdp'] = $mdp;
					
					$req = $cnx->prepare("SELECT * FROM etudiants WHERE login =:login");
					$req->bindValue(':login', $_POST['login'], PDO::PARAM_STR);
					$req->execute();
					
					$ligne2=$req->fetch(PDO::FETCH_OBJ);
					$_SESSION['Prenom'] = utf8_encode($ligne2->prenom);
					$_SESSION['Nom']= utf8_encode($ligne2->nom);
                    $_SESSION['Classe']= $ligne2->libelleClasse;

                    $_SESSION['Connect']=true;
                    header("Location: accueil.php");
                }/*else{
					$logfile = fopen("Connexion.php", "r");
                	echo fread($logfile,filesize("Connexion.php"))."Le mot de passe n'est pas correct <br>";
					fclose($logfile);
					echo "mot de passe incorect";
				}*/
               
			}
			/*else{
                $logfile = fopen("Connexion.php", "r");
               	echo fread($logfile,filesize("Connexion.php"))."L'identifiant n'est pas correct <br>";
				fclose($logfile);
			}*/
			$ligne=$req_pre->fetch(PDO::FETCH_OBJ);
		}
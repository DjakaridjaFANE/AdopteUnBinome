<?php
$DB_DSN ='mysql:host=localhost;dbname=AdopteUnBinome';
$DB_USER = 'root';
$DB_PASS = '';
?>
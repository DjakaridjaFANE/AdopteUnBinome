<?php
session_start();
require('db-config.php');
require('db-connexion.php');
require('Deconnexion.php');
if ($_SESSION['Connect'] == true){
            $req_pre = $cnx->prepare("SELECT * FROM demande");
            $req_pre->execute();
            $ligne_pre=$req_pre->fetch(PDO::FETCH_OBJ);
            while ($ligne_pre){
                $id = $ligne_pre->idDemande;
                if(!empty($_POST[$id])){
                    echo $_POST[$id];
                    if($_POST[$id] == 'accepter'){
                        $req = $cnx->prepare("INSERT INTO binomes(binome1, binome2, libelleMatiere) VALUES(:demandeur, :login, :matiere)");
                        $req->bindValue(':demandeur', $ligne_pre->demandeur , PDO::PARAM_STR);
                        $req->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
                        $req->bindValue(':matiere', $ligne_pre->libelleMatiere , PDO::PARAM_STR);
                        $req->execute();

                        $req2 = $cnx->prepare("UPDATE demande SET statut = 'accept' WHERE idDemande = :demande");
                        $req2->bindValue(':demande',$id, PDO::PARAM_STR);
                        $req2->execute();

                        $req3 = $cnx->prepare("UPDATE statut SET statut = '2' WHERE login = :login AND matiere = :matiere");
                        $req3->bindValue(':login', $_SESSION['login'], PDO::PARAM_STR);
                        $req3->bindValue(':matiere',$ligne_pre->libelleMatiere , PDO::PARAM_STR);
                        $req3->execute();

                        header("Location: demandes.php");
                    
                    }elseif($_POST[$id] == 'refuser'){
                        $req = $cnx->prepare("UPDATE demande SET statut = 'refus' WHERE idDemande = :demande");

                        $req->bindValue(':demande',$id , PDO::PARAM_STR);

                        $req->execute();
                        header("Location: demandes.php");
                        
                    }
                }
                $ligne_pre=$req_pre->fetch(PDO::FETCH_OBJ);
            }
        
        

            
}else{
    header("Location: Connexion.php");}
            
?>
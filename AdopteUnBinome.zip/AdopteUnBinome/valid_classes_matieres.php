<?php
session_start();
require('db-config.php');
require('db-connexion.php');
require('Deconnexion-admins.php');

if (isset ($_GET['action'])){
    if ($_GET['action'] == 'modifiermatiere'){
        if(!empty($_POST['libelleModifier'])){
            $req_pre = $cnx->prepare("UPDATE matieres SET libelle=:newlibelle WHERE libelle =:libelle");

            $req_pre->bindValue(':libelle', $_SESSION['libelle'], PDO::PARAM_STR);
            $req_pre->bindValue(':newlibelle', $_POST['libelleModifier'], PDO::PARAM_STR);

            $req_pre->execute();
        }
        if(!empty($_POST['classeModifier'])){
            $req_pre = $cnx->prepare("UPDATE matieres SET classe=:classe WHERE libelle =:libelle");

            $req_pre->bindValue(':libelle', $_SESSION['libelle'], PDO::PARAM_STR);
            $req_pre->bindValue(':classe', $_POST['classeModifier'], PDO::PARAM_STR);

            $req_pre->execute();
        }
        header("Location: classes_matieres.php");

	}
    if ($_GET['action'] == 'newmatiere')
	{
		
		$req_pre = $cnx->prepare("INSERT INTO matieres(libelle, classe) VALUES(:libelle, :classe)");
		
		$req_pre->bindValue(':libelle', $_POST['libelleAjout'], PDO::PARAM_STR);
		$req_pre->bindValue(':classe', $_POST['classeAjout'], PDO::PARAM_STR);
		$req_pre->execute();
		
		header("Location: classes_matieres.php");
	}
	
	if ($_GET['action'] == 'supprimermatiere')
	{
		
		$req_pre = $cnx->prepare("DELETE FROM matieres WHERE libelle = :libelle");
	
		$req_pre->bindValue(':libelle', $_GET['libelle'], PDO::PARAM_STR);
		$req_pre->execute();
		
        header("Location: classes_matieres.php");
	}
    if ($_GET['action'] == 'newclasse')
	{
		
		$req_pre = $cnx->prepare("INSERT INTO classes(libelle) VALUES(:libelle)");
		
		$req_pre->bindValue(':libelle', $_POST['libelleAjout'], PDO::PARAM_STR);

		$req_pre->execute();
		
		header("Location: classes_matieres.php");
	}
	
	if ($_GET['action'] == 'supprimerclasse')
	{
		
		$req_pre = $cnx->prepare("DELETE FROM classes WHERE libelle = :libelle");
	
		$req_pre->bindValue(':libelle', $_GET['libelle'], PDO::PARAM_STR);
		$req_pre->execute();
		
        header("Location: classes_matieres.php");
	}
}
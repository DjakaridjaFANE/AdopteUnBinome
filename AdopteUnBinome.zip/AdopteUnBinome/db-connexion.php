<?php
require('db-config.php');
try
{
	$cnx = new PDO($DB_DSN,$DB_USER,$DB_PASS);
}
catch (Exception $e)
{
	echo 'Erreur : '.$e->getMessage().'</br/>';
	echo 'N° : '.$e->getCode();
}						
?>
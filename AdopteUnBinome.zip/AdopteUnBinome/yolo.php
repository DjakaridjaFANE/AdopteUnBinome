 <!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/all.min.css">
</head>
<body>

<i class="fa fa-car"></i>
<i class="fa fa-car" ></i>
<i class="fa fa-car" style="font-size:60px;color:red;"></i>
<?php
session_start();
require('db-config.php');
require('db-connexion.php');
?>
<?php
$req_pre = $cnx->prepare("SELECT * FROM demande");
$req_pre->execute();
$ligne_pre=$req_pre->fetch(PDO::FETCH_OBJ);
// préparation de la requête : recherche d'un utilisateur particulier
		$req_pre = $cnx->prepare("SELECT * FROM etudiants");
		$req_pre->execute();
		$ligne=$req_pre->fetch(PDO::FETCH_OBJ);
		//$req_pre->execute();
        $x = "jbezos";
		//$req_pre->setFetchMode(PDO::FETCH_OBJ);
		//le résultat est récupéré sous forme d'objet
		while ($ligne)
		{
			if($ligne->login == $x)
			{
				$mdpbase = $ligne->password;
				$mdp = sha1($_POST['password']);
				if ($mdpbase == $mdp)
				{
					$_SESSION['login']= $x;
					$_SESSION['mdp'] = $mdp;
					
					$req = $cnx->prepare("SELECT * FROM etudiants WHERE login =:login");
					$req->bindValue(':login', $x, PDO::PARAM_STR);
					$req->execute();
					//$req->setFetchMode(PDO::FETCH_OBJ);
					//le résultat est récupéré sous forme d'objet
					//$ligne2=$req->fetch();
					$ligne2=$req->fetch(PDO::FETCH_OBJ);
					while($ligne2)
					{
						$_SESSION['Prenom'] = utf8_encode($ligne2->prenom);
						$_SESSION['Nom']= utf8_encode($ligne2->nom);
                        $_SESSION['Classe']= $ligne2->libelleClasse;

						$ligne2=$req->fetch(PDO::FETCH_OBJ);
						//$ligne2=$req->fetch();
					}
                    $_SESSION['Connect']=true;
                    header("Location: accueil.php");
                }//else{
					//$logfile = fopen("Connexion.php", "r");
                	//echo fread($logfile,filesize("Connexion.php"))."Le mot de passe n'est pas correct <br>";
					//fclose($logfile);
					//echo "mot de passe incorect";
				//}
               
			}
			//else
			//{	//echo $_SESSION["login"];
				//echo $x."x";
           //    $logfile = fopen("Connexion.php", "r");
           //    echo fread($logfile,filesize("Connexion.php"))."L'identifiant n'est pas correct <br>";
			//	fclose($logfile);
			//}
			$ligne=$req_pre->fetch(PDO::FETCH_OBJ);
		}

                        ?>
</body>
</html> 